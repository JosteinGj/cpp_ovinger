#pragma once
#include "Track.h"

class Vehicle : public Fl_Widget {
private:
	int currentGoal = 0;

	int color;	// Lite ekstra for � gi ulik farge p� gjeldande m�l
	static int numVehicles;

	PhysicsState ps;
	Obstacle status = Obstacle::None;
	double slideAngle = 0;

	drivingAlgorithm* steer;
	drawingAlgorithm* drawBody;

	const Track& t;

	void checkHitGoal();
	void checkHitObstacle();
	void draw() override;
public:

	Vehicle(double x, double y, double ang, drivingAlgorithm* isteer, drawingAlgorithm* draw, const Track& it)
		: steer(isteer), drawBody(draw), Fl_Widget{ 10,10,10,10 }, t{ it }, ps{x, y, ang}
	{color = numVehicles++; }
};