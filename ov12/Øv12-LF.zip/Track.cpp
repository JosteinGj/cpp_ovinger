#include "Track.h"
#include <FL/fl_draw.H>
#include <tuple>
#include <cmath>


Track::Track() : Fl_Widget{10,10,10,10,""}
	,spill{ "Sprites/spillSprite.jpeg" },
	boost{ "Sprites/boostSprite.jpeg" },
	peel{ "Sprites/peelSprite.jpeg" }
{
	// Eksempelbane
	constexpr int nCircles = 30;

	for (size_t i = 0; i < nCircles; i++)	// Lagar bana. Koda er ikkje relevant for �vinga
	{
		Obstacle toAdd = Obstacle::None;
		if (i % (nCircles / 4) == 0)
		{
			toAdd = Obstacle::Spill;
		}
		else if (i % (nCircles / 2) == 0)
		{
			toAdd = Obstacle::Peel;
		}
		else if (i % (nCircles / 3) == 0)
		{
			toAdd = Obstacle::Boost;
		}
		else
		{
			goals.push_back({
			ScreenWidth / 2 + ScreenWidth / 3.0*cos(i*2.0 / nCircles * 3.14),
			ScreenHeight / 2 - ScreenHeight / 3.0*sin(i*4.0 / nCircles * 3.14)
				});
			continue;
		}

		obstacles.push_back({
				  int(ScreenWidth / 2 + ScreenWidth / 3.0*cos(i*2.0 / nCircles * 3.14)),
				  int(ScreenHeight / 2 - ScreenHeight / 3.0*sin(i*4.0 / nCircles * 3.14)),
				  toAdd
			});
	}
}

void Track::draw()
{
	for (auto& o : obstacles)
	{
		switch (std::get<2>(o))
		{
		case Obstacle::Spill:
			spill.draw(std::get<0>(o) - 25, std::get<1>(o) - 25);
			break;
		case Obstacle::Peel:
			peel.draw(std::get<0>(o) - 15, std::get<1>(o) - 15);
			break;
		case Obstacle::Boost:
			boost.draw(std::get<0>(o) - 10, std::get<1>(o) - 10);
			break;
		default:
			break;
		}
	}

	fl_color(FL_BLACK);
	for (auto & p : goals)
	{
		fl_begin_line();
		fl_circle(p.first, p.second, goalRad);
		fl_end_line();
	}
}
