#pragma once
#include <FL/Fl_Widget.H>
#include <vector>
#include <FL/Fl_JPEG_Image.h>
#include "utilities.h"

class Track : public Fl_Widget
{
private:
	std::vector<std::pair<double, double>> goals;
	std::vector<std::tuple<double, double, Obstacle>> obstacles;
	void draw() override;
public:
	Track();
	const auto& getGoals() const { return goals; }
	const auto& getObstacles() const { return obstacles; }

	Fl_JPEG_Image spill, boost, peel;
};

