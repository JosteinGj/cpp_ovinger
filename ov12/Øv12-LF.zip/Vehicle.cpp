#include "Vehicle.h"
#include <FL/Fl.H>
#include <FL/fl_draw.H>
#include <cmath>
#include <tuple>

int Vehicle::numVehicles = 0;

inline bool circleCollision(int dx, int dy, int rSum)
{
	return (dx*dx + dy * dy < rSum*rSum);
}

void Vehicle::checkHitGoal()
{
	auto goals = t.getGoals();
	if (circleCollision(ps.x - goals[currentGoal].first, ps.y - goals[currentGoal].second, vehRad + goalRad))
	{
		currentGoal = (currentGoal + 1) % goals.size();
	}
}

void Vehicle::checkHitObstacle()
{
	for (auto& o : t.getObstacles())
	{
		switch (std::get<2>(o)) //std::get hentar ut det elementet gjeve i template-argumentet.
		{
		case Obstacle::Boost:
			if (circleCollision(ps.x - std::get<0>(o), ps.y - std::get<1>(o), vehRad + boostRad))
			{
				ps.grip = 2;
			}
			break;
		case Obstacle::Spill:
			if (circleCollision(ps.x - std::get<0>(o), ps.y - std::get<1>(o), vehRad + spillRad))
			{
				ps.grip = 0.5;
			}
			break;
		case Obstacle::Peel:
			if (status != Obstacle::Peel && circleCollision(ps.x - std::get<0>(o), ps.y - std::get<1>(o), vehRad + peelRad) && ps.vel > 2)
			{
				status = Obstacle::Peel;
				slideAngle = ps.angle;
			}
			break;
		default:
			break;
		}
	}
}

void Vehicle::draw() {

	checkHitGoal();
	checkHitObstacle();

	auto acc = steer(ps, t.getGoals(), currentGoal); // Nyttar drivingAlgorithm

	acc.first = (fmin(fmax(-1, acc.first), 1)); // S�rgjer for at dei ligg i [-1,1]
	acc.second = (fmin(fmax(-1, acc.second), 1));

	double moveAngle = ps.angle;
	if (status == Obstacle::Peel)
	{
		moveAngle = slideAngle;
		acc.first = 1 - 2 * (ps.vel > 0); // For at bremsing skal skje. If-setning kan ogs� brukast
		acc.second = 8;
		if (abs(ps.vel) < 0.05) status = Obstacle::None;
	}

	ps.grip += 0.01*(1 - ps.grip);
	ps.vel += 0.006 * ps.grip * acc.first *(6 - abs(ps.vel) + 5 * ((ps.vel > 0) != (acc.first > 0)));
	ps.angle += 0.03 * ps.grip * acc.second;
	ps.x += ps.vel*cos(moveAngle);
	ps.y += ps.vel*sin(moveAngle);

	ps.x = fmin(ScreenWidth - vehRad, fmax(vehRad, ps.x)); // At k�yret�yet ikkje g�r utanfor. Om du brukar radiusen er valfritt, men ser betre ut.
	ps.y = fmin(ScreenHeight - vehRad, fmax(vehRad, ps.y));

	fl_color(color);	//Teikner det gjeldande m�let.
	fl_begin_polygon();
	fl_circle(t.getGoals()[currentGoal].first, t.getGoals()[currentGoal].second, goalRad - (color + 1) * 2);
	fl_end_polygon();

	drawBody(ps);	// Teiknar med drawingAlgorithm
}
