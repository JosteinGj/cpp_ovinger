#pragma once
#include "utilities.h"
#include <FL/fl_draw.H>

drivingAlgorithm control;
drivingAlgorithm control2;

// Dette er berre eksemplar p� ulik algoritmer, og trengs ikkje � forst�


drawingAlgorithm full;

drivingAlgorithm dumb;
drivingAlgorithm simple;
drivingAlgorithm better;
drivingAlgorithm another;

void catBody(PhysicsState ps, Fl_Color col);

// Lite triks for � gi ulike fargar
template<Fl_Color col>
void cat(PhysicsState ps)
{
	catBody(ps, col);
}
