#include <chrono>
#include <thread>
#include <memory>

#include <FL/Fl_Double_Window.H>
#include <FL/Fl.H>

#include "utilities.h"
#include "Track.h"
#include "Vehicle.h"
#include "CustomAlgorithms.h"

#include <iostream>

int main() {
	auto win = std::make_unique<Fl_Double_Window>(ScreenWidth, ScreenHeight, "Testing");
	win->color(FL_WHITE);

	auto t = new Track;

	// Template-argumentet er eit triks for � gi ulike fargar
	auto mv0 = new Vehicle{ 250, 250, 0, control, cat<0>, *t };
	auto mv1 = new Vehicle{ 250, 250, 0, dumb , cat<1>, *t };
	auto mv2 = new Vehicle{ 250, 250, 0, simple , cat<2>, *t };
	auto mv3 = new Vehicle{ 250, 250, 0, better , cat<3>, *t };
	auto mv4 = new Vehicle{ 250, 250, 0, another , cat<4>, *t };

	win->end();
	win->show();

	auto nextDraw = std::chrono::steady_clock::now();

	while (win->shown())
	{
		// S�v til neste teikning
		std::this_thread::sleep_until(nextDraw);
		nextDraw += std::chrono::microseconds(1'000'000 / 60);

		Fl::check();
		Fl::redraw();
	}
}

